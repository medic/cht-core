#!/bin/bash

set -eu -o pipefail

# if you're gonna put this in CI, consider using alpine/helm:4.2
# which has helm, git, curl and what ever else you might need
# to publish the builds 

# set up files for this version
TAG_VERSION=$1

read -r -p "Do you want to package helm chart for version ${TAG_VERSION} of the CHT? You must have this branch checked out already!  (y/N) " yn
case "${yn}" in
  [yY] | [yY][eE][sS]) ;;
  *) echo "aborted"; exit 1 ;;
esac

# update all values
sed -i "s/ (CHT) v4/ (CHT)/" Chart.yaml
sed -i "s/version: .*/version: $TAG_VERSION/" Chart.yaml
sed -i "s/appVersion: .*/appVersion: \"$TAG_VERSION\"/" Chart.yaml
sed -i "s/{{cht_version}}/$TAG_VERSION/g" values/base.yaml
sed -i "s/{{cht_image_tag}}/$TAG_VERSION/g" values/base.yaml

# test values
./validate-templates.sh

# lint the chart before publishing
# disabling for now as this throws an error, but maybe that's expected?
# [INFO] values.yaml: file does not exist
#[ERROR] templates/: cht-chart/templates/sentinel/deployment.yaml:29:28
#  executing "cht-chart/templates/sentinel/deployment.yaml" at <.Values.upstream_servers.docker_registry>:
#    nil pointer evaluating interface {}.docker_registry
#
#Error: 1 chart(s) linted, 1 chart(s) failed
#helm lint .

# package version, merge with existing index.yaml
helm package . -d ../helm-releases

if [ ! -f ../helm-releases/index.yaml ]; then
	# do this only first time
	helm repo index ../helm-releases  --url https://helm.app.medicmobile.org/cht-core
else
	# do this every time
	helm repo index ../helm-releases --merge ../helm-releases/index.yaml --url https://helm.app.medicmobile.org/cht-core
fi

# reset files for the next time we run this script
git checkout values/base.yaml Chart.yaml
